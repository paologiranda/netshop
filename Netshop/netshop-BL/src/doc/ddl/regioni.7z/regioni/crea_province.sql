CREATE table "PROVINCE" (
    "IDPROVINCIA"    NUMBER(4,0) NOT NULL,
    "NOMEPROVINCIA"  VARCHAR2(20) NOT NULL,
    "IDREGIONE"      NUMBER(4,0) NOT NULL,
    "SIGLAPROVINCIA" CHAR(2),
    constraint  "PROVINCE_PK" primary key ("IDPROVINCIA")
)
/

CREATE sequence "PROVINCE_SEQ" 
/

CREATE trigger "BI_PROVINCE"  
  before insert on "PROVINCE"              
  for each row 
begin  
  if :NEW."IDPROVINCIA" is null then
    select "PROVINCE_SEQ".nextval into :NEW."IDPROVINCIA" from dual;
  end if;
end;
/   
