CREATE table "REGIONI" (
    "IDREGIONE"   NUMBER(4,0) NOT NULL,
    "NOMEREGIONE" VARCHAR2(50) NOT NULL,
    constraint  "REGIONI_PK" primary key ("IDREGIONE")
)
/

CREATE sequence "REGIONI_SEQ" 
/

CREATE trigger "BI_REGIONI"  
  before insert on "REGIONI"              
  for each row 
begin  
  if :NEW."IDREGIONE" is null then
    select "REGIONI_SEQ".nextval into :NEW."IDREGIONE" from dual;
  end if;
end;
/