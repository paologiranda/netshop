CREATE TABLE "COMUNI" (
  "ID" NUMBER(5,0) NOT NULL,
  "NOME" VARCHAR2(50) NOT NULL,
  "IDPROVINCIA" NUMBER(4,0) NOT NULL,
  "IDREGIONE" NUMBER(4,0) NOT NULL,
  "CATASTO" VARCHAR2(5), 
  constraint "COMUNI_PK" primary key ("ID")
)
/

CREATE sequence "COMUNI_SEQ"
/

CREATE trigger "BI_COMUNI"
	before insert on "COMUNI"
	for each row
begin
	if :NEW."ID" is null then
		select "COMUNI_SEQ".nextval into :NEW."ID" from dual;
	end if;
end;
/
